export type Mode = "coin" | "die" | "dice";

export interface Outcome {
  id: string;
  label: string;
  short: string;
  theory: number;
  ways?: number;
  waysTotal?: number;
}

export interface Roll {
  index: number;
  faces: number[];
}

export interface Starter {
  id: string;
  label: string;
  mode: Mode;
  pHeads: number;
  trials: number;
  speed: number;
}

export const TRIAL_PRESETS = [20, 100, 500, 2000, 10000] as const;
export const MAX_TRIALS = 50_000;
export const MIN_HEADS = 0.05;
export const MAX_HEADS = 0.95;

export const STARTERS: Starter[] = [
  { id: "fair", label: "Fair coin", mode: "coin", pHeads: 0.5, trials: 100, speed: 8 },
  { id: "heavy", label: "Heavy heads", mode: "coin", pHeads: 0.7, trials: 200, speed: 28 },
  { id: "die", label: "Single die", mode: "die", pHeads: 0.5, trials: 120, speed: 14 },
  { id: "seven", label: "Why 7 is common", mode: "dice", pHeads: 0.5, trials: 360, speed: 40 },
];

const DICE_WAYS = [1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1];

export function outcomesFor(mode: Mode, pHeads: number): Outcome[] {
  if (mode === "coin") {
    const p = clampHeads(pHeads);
    return [
      { id: "H", label: "Heads", short: "H", theory: p },
      { id: "T", label: "Tails", short: "T", theory: 1 - p },
    ];
  }
  if (mode === "die") {
    return [1, 2, 3, 4, 5, 6].map((face) => ({
      id: String(face),
      label: `Face ${face}`,
      short: String(face),
      theory: 1 / 6,
      ways: 1,
      waysTotal: 6,
    }));
  }
  return DICE_WAYS.map((ways, i) => {
    const sum = i + 2;
    return {
      id: String(sum),
      label: `Sum ${sum}`,
      short: String(sum),
      theory: ways / 36,
      ways,
      waysTotal: 36,
    };
  });
}

export function defaultFocus(mode: Mode): number {
  if (mode === "coin") return 0;
  if (mode === "die") return 0;
  return 5;
}

export function clampHeads(p: number): number {
  const stepped = Math.round(p * 20) / 20;
  return Math.min(MAX_HEADS, Math.max(MIN_HEADS, stepped));
}

export function clampTrials(n: number): number {
  if (!Number.isFinite(n)) return 100;
  return Math.min(MAX_TRIALS, Math.max(1, Math.floor(n)));
}

export function rollOutcome(mode: Mode, pHeads: number): Roll {
  if (mode === "coin") {
    const index = Math.random() < clampHeads(pHeads) ? 0 : 1;
    return { index, faces: [index] };
  }
  const a = 1 + Math.floor(Math.random() * 6);
  if (mode === "die") return { index: a - 1, faces: [a] };
  const b = 1 + Math.floor(Math.random() * 6);
  return { index: a + b - 2, faces: [a, b] };
}

export function pairsForSum(sum: number): string {
  const pairs: string[] = [];
  for (let a = 1; a <= 6; a += 1) {
    const b = sum - a;
    if (b >= 1 && b <= 6) pairs.push(`${a}+${b}`);
  }
  return pairs.join(", ");
}

export function spinDuration(speed: number): number {
  if (speed > 22) return 0;
  const t = Math.min(1, Math.max(0, speed / 22));
  return Math.round(560 - t * 420);
}

export function batchSize(speed: number, remaining: number): number {
  if (remaining <= 0) return 0;
  if (speed <= 22) return 1;
  const t = Math.min(1, (speed - 22) / 78);
  const n = Math.max(1, Math.round(10 ** (t * 3.15)));
  return Math.min(remaining, n, 800);
}

export function speedLabel(speed: number): string {
  if (speed <= 8) return "One at a time";
  if (speed <= 22) return "Watch each";
  if (speed <= 48) return "Steady";
  if (speed <= 76) return "Fast";
  return "Burst";
}

export function speedHint(speed: number): string {
  if (speed <= 22) return "Each roll lands before the next one starts.";
  if (speed <= 76) return "Rolls arrive in slices, and the chart updates with them.";
  return "Large slices. The bars still move while the run is going.";
}

export function formatPct(probability: number, digits = 1): string {
  return `${(probability * 100).toFixed(digits)}%`;
}

export function prettyPct(probability: number): string {
  const hundred = probability * 100;
  const nearest = Math.round(hundred);
  if (Math.abs(hundred - nearest) < 0.05) return `${nearest}%`;
  return `${hundred.toFixed(1)}%`;
}

export function formatGap(points: number): string {
  if (points > 0.05) return `+${points.toFixed(1)}`;
  if (points < -0.05) return `−${Math.abs(points).toFixed(1)}`;
  return "0.0";
}

export function standardError(p: number, n: number): number {
  if (n <= 0) return 0;
  return Math.sqrt((p * (1 - p)) / n);
}

export function meanAbsGap(counts: number[], theories: number[], n: number): number | null {
  if (n <= 0 || theories.length === 0) return null;
  let sum = 0;
  for (let i = 0; i < theories.length; i += 1) {
    sum += Math.abs(counts[i] / n - theories[i]);
  }
  return (sum / theories.length) * 100;
}

export function modeLesson(mode: Mode, pHeads: number): string {
  if (mode === "coin") {
    const p = Math.round(clampHeads(pHeads) * 100);
    if (p === 50) {
      return "A fair coin has no memory. A streak of heads does not make tails due.";
    }
    return `Heads is set to ${p}%, so tails is ${100 - p}%. The coin is not trying to catch up.`;
  }
  if (mode === "die") {
    return "Each face has the same chance, 1 in 6. Early on, one face can lead by luck alone.";
  }
  return "Sums are not equally likely. More face pairs add to 7 than to 2.";
}

export function focusLesson(mode: Mode, outcome: Outcome): string {
  if (mode === "dice" && outcome.ways != null) {
    const ways = outcome.ways === 1 ? "1 way" : `${outcome.ways} ways`;
    return `${outcome.label} can happen ${ways} out of 36: ${pairsForSum(Number(outcome.id))}.`;
  }
  if (mode === "die") {
    return `${outcome.label} is no more likely than any other face. The previous roll does not change this one.`;
  }
  return `${outcome.label} does not get more likely just because it has been rare so far.`;
}

export function wobbleCopy(n: number, share: number, theory: number, label: string): string {
  if (n <= 0) return "Run some trials. The gap between what happened and the expected chance is the thing to watch.";
  if (n < 8) return "With so few trials, a large gap is normal. Keep going before you judge.";
  const se = standardError(theory, n);
  const band = se * 100;
  const gap = Math.abs(share - theory);
  const usual = `${label} usually lands within about ±${band.toFixed(1)} points of ${prettyPct(theory)} at this count.`;
  if (gap <= se) return `${usual} This run is inside that usual wobble.`;
  if (gap <= 2 * se) return `${usual} This gap is a little wide, and still ordinary noise.`;
  return `${usual} This gap is wider than usual. It can still be luck — add more trials before you decide the chance is wrong.`;
}

export interface TracePoint {
  n: number;
  shares: number[];
}

export function pushTrace(trace: TracePoint[], n: number, counts: number[]): TracePoint[] {
  const shares = counts.map((count) => (n === 0 ? 0 : count / n));
  const next = trace.slice();
  const point = { n, shares };
  if (next.length > 0 && next[next.length - 1].n === n) next[next.length - 1] = point;
  else next.push(point);
  if (next.length <= 300) return next;
  const kept: TracePoint[] = [next[0]];
  for (let i = 1; i < next.length - 1; i += 2) kept.push(next[i]);
  kept.push(next[next.length - 1]);
  return kept;
}
