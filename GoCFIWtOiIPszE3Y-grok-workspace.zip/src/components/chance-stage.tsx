import { useEffect, useRef } from "react";
import type { Mode } from "@/lib/chance";

const PIPS: Record<number, boolean[]> = {
  1: [false, false, false, false, true, false, false, false, false],
  2: [true, false, false, false, false, false, false, false, true],
  3: [true, false, false, false, true, false, false, false, true],
  4: [true, false, true, false, false, false, true, false, true],
  5: [true, false, true, false, true, false, true, false, true],
  6: [true, false, true, true, false, true, true, false, true],
};

function Pips({ value, small }: { value: number | null; small?: boolean }) {
  const cells = value == null ? Array.from({ length: 9 }, () => false) : PIPS[value];
  return (
    <div className={small ? "pip-grid pip-grid-sm" : "pip-grid"} aria-hidden="true">
      {cells.map((on, i) => (
        <span key={i} className={on ? "pip pip-on" : "pip"} />
      ))}
    </div>
  );
}

function DieFace({
  value,
  small,
  spinId,
  spinMs,
}: {
  value: number | null;
  small?: boolean;
  spinId: number;
  spinMs: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (spinMs <= 0) {
      el.classList.remove("die-land");
      return;
    }
    el.classList.remove("die-land");
    void el.offsetWidth;
    el.style.animationDuration = `${spinMs}ms`;
    el.classList.add("die-land");
  }, [spinId, spinMs]);

  return (
    <div ref={ref} className={small ? "die-tile die-tile-sm" : "die-tile"}>
      <Pips value={value} small={small} />
      <span className="sr-only">{value == null ? "No roll yet" : `Face ${value}`}</span>
    </div>
  );
}

function Coin({
  side,
  spinId,
  spinMs,
}: {
  side: "H" | "T" | null;
  spinId: number;
  spinMs: number;
}) {
  const rot = useRef(0);
  const body = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = body.current;
    if (!el || side == null) return;
    const base = side === "H" ? 0 : 180;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || spinMs <= 0) {
      rot.current = base;
      el.style.transitionDuration = "0ms";
      el.style.transform = `rotateY(${base}deg)`;
      return;
    }
    let next = base + 360 * Math.ceil((rot.current - base + 1) / 360);
    if (next <= rot.current) next += 360;
    if (next < rot.current + 360) next += 360;
    rot.current = next;
    el.style.transitionDuration = `${spinMs}ms`;
    el.style.transform = `rotateY(${next}deg)`;
  }, [side, spinId, spinMs]);

  return (
    <div className="coin-scene" aria-hidden="true">
      <div ref={body} className="coin-body" style={{ transform: "rotateY(0deg)" }}>
        <div className="coin-face">Heads</div>
        <div className="coin-face coin-tails">Tails</div>
      </div>
    </div>
  );
}

export function ChanceStage({
  mode,
  faces,
  status,
  spinId,
  spinMs,
}: {
  mode: Mode;
  faces: number[];
  status: string;
  spinId: number;
  spinMs: number;
}) {
  return (
    <div className="flex min-h-48 flex-col items-center justify-center gap-4 py-2">
      {mode === "coin" && faces.length === 0 ? (
        <div className="coin-idle" aria-hidden="true">
          <span>Coin</span>
        </div>
      ) : null}
      {mode === "coin" && faces.length > 0 ? (
        <Coin side={faces[0] === 0 ? "H" : "T"} spinId={spinId} spinMs={spinMs} />
      ) : null}
      {mode === "die" ? <DieFace value={faces[0] ?? null} spinId={spinId} spinMs={spinMs} /> : null}
      {mode === "dice" ? (
        <div className="flex items-center gap-3">
          <DieFace value={faces[0] ?? null} small spinId={spinId} spinMs={spinMs} />
          <span className="font-display text-2xl text-muted" aria-hidden="true">
            +
          </span>
          <DieFace value={faces[1] ?? null} small spinId={spinId + 1} spinMs={spinMs} />
          <span className="font-display text-4xl tabular-nums text-ink">
            {faces.length === 2 ? faces[0] + faces[1] : "–"}
          </span>
        </div>
      ) : null}
      <p className="text-sm font-medium text-muted">{status}</p>
    </div>
  );
}
