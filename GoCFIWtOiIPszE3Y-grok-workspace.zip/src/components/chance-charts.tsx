import { useEffect, useState } from "react";
import {
  Bar,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { Outcome, TracePoint } from "@/lib/chance";
import { formatPct } from "@/lib/chance";

export interface HistRow {
  id: string;
  label: string;
  short: string;
  observed: number;
  theory: number;
  count: number;
  expected: number;
}

function HistTip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ payload: HistRow }>;
}) {
  if (!active || !payload?.length) return null;
  const row = payload[0].payload;
  return (
    <div className="rounded-sm border border-line bg-surface px-3 py-2 text-sm shadow-panel">
      <p className="font-medium text-ink">{row.label}</p>
      <p className="tabular-nums text-muted">
        Happened {row.count.toLocaleString()} · {row.observed.toFixed(1)}%
      </p>
      <p className="tabular-nums text-muted">
        Expected about {row.expected.toFixed(1)} · {row.theory.toFixed(1)}%
      </p>
    </div>
  );
}

function ShareTip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ payload: { n: number; share: number } }>;
}) {
  if (!active || !payload?.length) return null;
  const row = payload[0].payload;
  return (
    <div className="rounded-sm border border-line bg-surface px-3 py-2 text-sm shadow-panel">
      <p className="tabular-nums text-ink">After {row.n.toLocaleString()} trials</p>
      <p className="tabular-nums text-muted">{formatPct(row.share)} so far</p>
    </div>
  );
}

export function ChanceCharts({
  rows,
  focus,
  onFocus,
  trace,
  theory,
  outcomeLabel,
}: {
  rows: HistRow[];
  focus: number;
  onFocus: (index: number) => void;
  trace: TracePoint[];
  theory: number;
  outcomeLabel: string;
}) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);

  const peak = Math.max(1, ...rows.map((row) => Math.max(row.observed, row.theory)));
  const yMax = Math.min(100, peak * 1.28);
  const line = trace.map((point) => ({
    n: point.n,
    share: point.shares[focus] ?? 0,
  }));
  const lastN = line.length > 0 ? line[line.length - 1].n : 2;

  return (
    <div className="flex flex-col gap-4">
      <section className="min-w-0 rounded-xl border border-line bg-surface p-5" aria-labelledby="hist-title">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 id="hist-title" className="font-display text-2xl text-ink">
              What happened
            </h2>
            <p className="mt-1 max-w-xl text-sm text-pretty text-muted">
              Bars are the trials you have rolled. The dashed line is the chance you should expect if you kept going.
            </p>
          </div>
          <ul className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted">
            <li className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-sm bg-accent" aria-hidden="true" />
              Happened
            </li>
            <li className="flex items-center gap-2">
              <span className="h-px w-5 border-t-2 border-dashed border-ink" aria-hidden="true" />
              Expected
            </li>
          </ul>
        </div>
        <div className="h-64 min-w-0 overflow-hidden sm:h-72" role="img" aria-label="Histogram comparing what happened with the expected chance. Exact numbers are in the table.">
          {ready ? (
            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <ComposedChart data={rows} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="var(--color-line)" />
                <XAxis
                  dataKey="short"
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  tickLine={false}
                  axisLine={false}
                  interval={0}
                />
                <YAxis
                  domain={[0, yMax]}
                  tickFormatter={(value: number) => `${Math.round(value)}%`}
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  tickLine={false}
                  axisLine={false}
                  width={44}
                />
                <Tooltip content={<HistTip />} cursor={{ fill: "var(--color-elevated)" }} />
                <Bar
                  dataKey="observed"
                  maxBarSize={48}
                  radius={[4, 4, 0, 0]}
                  isAnimationActive={false}
                  cursor="pointer"
                  onClick={(_data, index) => {
                    if (typeof index === "number") onFocus(index);
                  }}
                >
                  {rows.map((row, index) => (
                    <Cell
                      key={row.id}
                      fill="var(--color-accent)"
                      fillOpacity={index === focus ? 1 : 0.45}
                    />
                  ))}
                </Bar>
                <Line
                  type="linear"
                  dataKey="theory"
                  stroke="var(--color-ink)"
                  strokeDasharray="4 3"
                  strokeWidth={1.5}
                  dot={{ r: 2.5, stroke: "var(--color-ink)", strokeWidth: 1.5, fill: "var(--color-surface)" }}
                  activeDot={{ r: 4 }}
                  isAnimationActive={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full rounded-sm bg-elevated" />
          )}
        </div>
        <p className="mt-2 text-sm text-muted">Select a bar or a table row to follow that outcome below.</p>
      </section>

      <section className="min-w-0 rounded-xl border border-line bg-surface p-5" aria-labelledby="share-title">
        <h2 id="share-title" className="font-display text-2xl text-ink">
          Share of {outcomeLabel} so far
        </h2>
        <p className="mt-1 max-w-xl text-sm text-pretty text-muted">
          Early on this swings hard. More trials pull it toward the dashed line. That is the law of large numbers.
        </p>
        <div className="mt-4 h-48 min-w-0 overflow-hidden" role="img" aria-label={`Running share of ${outcomeLabel} compared with the expected chance.`}>
          {ready && line.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <LineChart data={line} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="var(--color-line)" />
                <XAxis
                  dataKey="n"
                  type="number"
                  domain={[1, Math.max(lastN, 2)]}
                  tickFormatter={(value: number) => value.toLocaleString()}
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  domain={[0, 1]}
                  tickFormatter={(value: number) => `${Math.round(value * 100)}%`}
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  tickLine={false}
                  axisLine={false}
                  width={44}
                />
                <Tooltip content={<ShareTip />} />
                <ReferenceLine
                  y={theory}
                  stroke="var(--color-ink)"
                  strokeDasharray="4 3"
                  strokeWidth={1.5}
                />
                <Line
                  type="monotone"
                  dataKey="share"
                  stroke="var(--color-accent)"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex h-full items-center justify-center rounded-sm bg-elevated px-4 text-center text-sm text-muted">
              The line starts with the first trial.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

export function outcomeRows(outcomes: Outcome[], counts: number[], n: number): HistRow[] {
  return outcomes.map((outcome, index) => {
    const count = counts[index] ?? 0;
    return {
      id: outcome.id,
      label: outcome.label,
      short: outcome.short,
      observed: n === 0 ? 0 : (count / n) * 100,
      theory: outcome.theory * 100,
      count,
      expected: outcome.theory * n,
    };
  });
}
