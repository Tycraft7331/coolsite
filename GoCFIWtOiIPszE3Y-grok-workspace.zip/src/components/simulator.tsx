import { useEffect, useMemo, useRef, useState } from "react";
import { Pause, Play, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ChanceStage } from "@/components/chance-stage";
import { ChanceCharts, outcomeRows } from "@/components/chance-charts";
import { cn } from "@/lib/cn";
import {
  MAX_HEADS,
  MAX_TRIALS,
  MIN_HEADS,
  STARTERS,
  TRIAL_PRESETS,
  batchSize,
  clampHeads,
  clampTrials,
  defaultFocus,
  focusLesson,
  formatGap,
  meanAbsGap,
  modeLesson,
  outcomesFor,
  prettyPct,
  pushTrace,
  rollOutcome,
  speedHint,
  speedLabel,
  spinDuration,
  wobbleCopy,
  type Mode,
  type TracePoint,
} from "@/lib/chance";

interface Engine {
  mode: Mode;
  pHeads: number;
  speed: number;
  trials: number;
  focus: number;
  running: boolean;
  remaining: number;
  counts: number[];
  n: number;
  faces: number[];
  trace: TracePoint[];
  spinId: number;
  spinMs: number;
  settling: boolean;
  token: number;
  timer: number;
  raf: number;
  announceOnStop: boolean;
}

interface Snapshot {
  mode: Mode;
  pHeads: number;
  speed: number;
  trials: number;
  focus: number;
  running: boolean;
  remaining: number;
  counts: number[];
  n: number;
  faces: number[];
  trace: TracePoint[];
  spinId: number;
  spinMs: number;
  settling: boolean;
}

function freshCounts(mode: Mode, pHeads: number) {
  return Array.from({ length: outcomesFor(mode, pHeads).length }, () => 0);
}

function createEngine(): Engine {
  return {
    mode: "coin",
    pHeads: 0.5,
    speed: 12,
    trials: 100,
    focus: 0,
    running: false,
    remaining: 0,
    counts: freshCounts("coin", 0.5),
    n: 0,
    faces: [],
    trace: [],
    spinId: 0,
    spinMs: 0,
    settling: false,
    token: 0,
    timer: 0,
    raf: 0,
    announceOnStop: false,
  };
}

function shot(engine: Engine): Snapshot {
  return {
    mode: engine.mode,
    pHeads: engine.pHeads,
    speed: engine.speed,
    trials: engine.trials,
    focus: engine.focus,
    running: engine.running,
    remaining: engine.remaining,
    counts: engine.counts.slice(),
    n: engine.n,
    faces: engine.faces.slice(),
    trace: engine.trace.map((point) => ({ n: point.n, shares: point.shares.slice() })),
    spinId: engine.spinId,
    spinMs: engine.spinMs,
    settling: engine.settling,
  };
}

function prefersReduced() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function stopTimers(engine: Engine) {
  window.clearTimeout(engine.timer);
  window.cancelAnimationFrame(engine.raf);
}

const MODES: { id: Mode; label: string }[] = [
  { id: "coin", label: "Coin" },
  { id: "die", label: "One die" },
  { id: "dice", label: "Two dice" },
];

export function Simulator() {
  const engineRef = useRef<Engine | null>(null);
  if (engineRef.current == null) engineRef.current = createEngine();
  const engine = engineRef.current;

  const [snap, setSnap] = useState(() => shot(engine));
  const [announcement, setAnnouncement] = useState("");
  const [trialDraft, setTrialDraft] = useState("100");

  const api = useRef({
    pump: () => {},
    landOne: (_continueQueue: boolean, _visual: number, _wait: number) => {},
    finishNote: () => {},
  });

  api.current.finishNote = () => {
    const current = engineRef.current;
    if (!current) return;
    const outcomes = outcomesFor(current.mode, current.pHeads);
    const outcome = outcomes[current.focus] ?? outcomes[0];
    const share = current.n === 0 ? 0 : current.counts[current.focus] / current.n;
    setAnnouncement(
      `Run finished. ${current.n.toLocaleString()} trials. ${outcome.label} ${prettyPct(share)}. Expected ${prettyPct(outcome.theory)}.`,
    );
  };

  api.current.landOne = (continueQueue, visual, wait) => {
    const current = engineRef.current;
    if (!current) return;
    const token = current.token;
    const rolled = rollOutcome(current.mode, current.pHeads);
    current.settling = true;
    current.faces = rolled.faces;
    current.spinId += 1;
    current.spinMs = visual;
    setSnap(shot(current));
    current.timer = window.setTimeout(() => {
      const live = engineRef.current;
      if (!live || live.token !== token) return;
      live.counts[rolled.index] += 1;
      live.n += 1;
      if (live.remaining > 0) live.remaining -= 1;
      live.trace = pushTrace(live.trace, live.n, live.counts);
      live.settling = false;
      live.spinMs = 0;
      const queueDone = live.remaining <= 0;
      if (!continueQueue || !live.running || queueDone) {
        const shouldAnnounce = live.announceOnStop && queueDone;
        live.running = false;
        if (shouldAnnounce) {
          live.announceOnStop = false;
          api.current.finishNote();
        }
        setSnap(shot(live));
        return;
      }
      setSnap(shot(live));
      api.current.pump();
    }, wait);
  };

  api.current.pump = () => {
    const current = engineRef.current;
    if (!current || !current.running) return;
    if (current.remaining <= 0) {
      current.running = false;
      if (current.announceOnStop) {
        current.announceOnStop = false;
        api.current.finishNote();
      }
      setSnap(shot(current));
      return;
    }
    const reduce = prefersReduced();
    const visual = reduce ? 0 : spinDuration(current.speed);
    const wait = visual > 0 ? visual : current.speed <= 22 ? 80 : 0;
    if (wait > 0) {
      api.current.landOne(true, visual, wait);
      return;
    }
    const count = batchSize(current.speed, current.remaining);
    let faces = current.faces;
    for (let i = 0; i < count; i += 1) {
      const rolled = rollOutcome(current.mode, current.pHeads);
      current.counts[rolled.index] += 1;
      faces = rolled.faces;
    }
    current.n += count;
    current.remaining -= count;
    current.faces = faces;
    current.spinMs = 0;
    current.settling = false;
    current.trace = pushTrace(current.trace, current.n, current.counts);
    if (current.remaining <= 0) {
      current.running = false;
      if (current.announceOnStop) {
        current.announceOnStop = false;
        api.current.finishNote();
      }
    }
    setSnap(shot(current));
    if (current.running) {
      current.raf = window.requestAnimationFrame(() => api.current.pump());
    }
  };

  useEffect(() => {
    const current = engineRef.current;
    return () => {
      if (!current) return;
      current.token += 1;
      current.running = false;
      stopTimers(current);
    };
  }, []);

  function publish() {
    const current = engineRef.current;
    if (current) setSnap(shot(current));
  }

  function wipeSample(next?: { mode?: Mode; pHeads?: number }) {
    const current = engineRef.current;
    if (!current) return;
    current.token += 1;
    current.running = false;
    current.settling = false;
    current.announceOnStop = false;
    stopTimers(current);
    if (next?.mode) current.mode = next.mode;
    if (next?.pHeads != null) current.pHeads = clampHeads(next.pHeads);
    current.focus = defaultFocus(current.mode);
    current.counts = freshCounts(current.mode, current.pHeads);
    current.n = 0;
    current.remaining = 0;
    current.faces = [];
    current.trace = [];
    current.spinMs = 0;
    setAnnouncement("");
    publish();
  }

  function onMode(mode: Mode) {
    if (mode === engineRef.current?.mode) return;
    wipeSample({ mode });
  }

  function onHeads(value: number) {
    const next = clampHeads(value);
    const current = engineRef.current;
    if (!current || next === current.pHeads) return;
    wipeSample({ pHeads: next });
  }

  function onSpeed(value: number) {
    const current = engineRef.current;
    if (!current) return;
    current.speed = value;
    publish();
  }

  function onFocus(index: number) {
    const current = engineRef.current;
    if (!current) return;
    current.focus = index;
    publish();
  }

  function chooseTrials(count: number) {
    const current = engineRef.current;
    if (!current) return;
    current.trials = clampTrials(count);
    setTrialDraft(String(current.trials));
    publish();
  }

  function applyStarter(id: string) {
    const starter = STARTERS.find((item) => item.id === id);
    const current = engineRef.current;
    if (!starter || !current) return;
    current.speed = starter.speed;
    current.trials = starter.trials;
    setTrialDraft(String(starter.trials));
    wipeSample({ mode: starter.mode, pHeads: starter.pHeads });
  }

  function reset() {
    wipeSample();
  }

  function run() {
    const current = engineRef.current;
    if (!current) return;
    if (current.running) {
      current.running = false;
      current.announceOnStop = false;
      window.cancelAnimationFrame(current.raf);
      publish();
      return;
    }
    if (current.settling) return;
    if (current.remaining <= 0) {
      const count = clampTrials(Number(trialDraft));
      current.trials = count;
      current.remaining = count;
      setTrialDraft(String(count));
    }
    current.running = true;
    current.announceOnStop = true;
    publish();
    api.current.pump();
  }

  function step() {
    const current = engineRef.current;
    if (!current || current.running || current.settling) return;
    const reduce = prefersReduced();
    api.current.landOne(false, reduce ? 0 : 320, reduce ? 0 : 320);
  }

  const outcomes = useMemo(
    () => outcomesFor(snap.mode, snap.pHeads),
    [snap.mode, snap.pHeads],
  );
  const focusIndex = Math.min(snap.focus, outcomes.length - 1);
  const focus = outcomes[focusIndex];
  const rows = useMemo(
    () => outcomeRows(outcomes, snap.counts, snap.n),
    [outcomes, snap.counts, snap.n],
  );
  const share = snap.n === 0 ? 0 : (snap.counts[focusIndex] ?? 0) / snap.n;
  const gap = snap.n === 0 ? null : (share - focus.theory) * 100;
  const averageGap = meanAbsGap(
    snap.counts,
    outcomes.map((outcome) => outcome.theory),
    snap.n,
  );

  let status = "Ready";
  if (snap.settling) status = "In the air";
  else if (snap.mode === "coin" && snap.faces.length > 0) status = snap.faces[0] === 0 ? "Heads" : "Tails";
  else if (snap.mode === "die" && snap.faces.length > 0) status = `Face ${snap.faces[0]}`;
  else if (snap.mode === "dice" && snap.faces.length === 2) status = `Sum ${snap.faces[0] + snap.faces[1]}`;

  const parsedTrials = clampTrials(Number(trialDraft));
  const draftOk = Number.isFinite(Number(trialDraft)) && Number(trialDraft) >= 1;
  let primary = `Run ${parsedTrials.toLocaleString()}`;
  if (snap.running) primary = "Pause";
  else if (snap.settling) primary = "Landing";
  else if (snap.remaining > 0) primary = `Resume ${snap.remaining.toLocaleString()}`;

  return (
    <main className="mx-auto w-full max-w-6xl overflow-x-clip px-4 pt-8 pb-24 sm:px-6">
      <p className="sr-only" aria-live="polite">
        {announcement}
      </p>
      <header className="max-w-2xl">
        <p className="text-sm font-medium tracking-wide text-muted">Probability bench</p>
        <h1 className="mt-2 font-display text-display text-ink">The Long Run</h1>
        <p className="mt-3 max-w-xl text-pretty text-muted">
          Flip a coin or roll dice, again and again. Watch the bars chase the chance you should expect.
        </p>
      </header>

      <div className="mt-6 flex flex-wrap gap-2" role="group" aria-label="Starting setups">
        {STARTERS.map((starter) => (
          <Button key={starter.id} variant="quiet" className="border border-line bg-surface" onClick={() => applyStarter(starter.id)}>
            {starter.label}
          </Button>
        ))}
      </div>

      <div className="mt-6 grid min-w-0 gap-4 lg:grid-cols-3 lg:items-start lg:gap-6">
        <div className="flex min-w-0 flex-col gap-4">
          <section className="rounded-xl border border-line bg-surface p-5">
            <div className="grid grid-cols-3 gap-1 rounded-md bg-elevated p-1" role="radiogroup" aria-label="Experiment">
              {MODES.map((mode) => {
                const on = snap.mode === mode.id;
                return (
                  <button
                    key={mode.id}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    className={cn(
                      "press min-h-11 rounded-sm px-2 text-sm font-medium",
                      on ? "bg-accent text-accent-fg" : "text-muted hover:text-ink",
                    )}
                    onClick={() => onMode(mode.id)}
                  >
                    {mode.label}
                  </button>
                );
              })}
            </div>
            <ChanceStage
              mode={snap.mode}
              faces={snap.faces}
              status={status}
              spinId={snap.spinId}
              spinMs={snap.spinMs}
            />
            <dl className="grid grid-cols-2 gap-3 border-t border-line pt-4">
              <div>
                <dt className="text-sm text-muted">Trials so far</dt>
                <dd className="font-mono text-xl tabular-nums text-ink">{snap.n.toLocaleString()}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Following {focus.short}</dt>
                <dd className="font-mono text-xl tabular-nums text-ink">{snap.n === 0 ? "—" : prettyPct(share)}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Expected</dt>
                <dd className="font-mono text-xl tabular-nums text-ink">{prettyPct(focus.theory)}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Gap, points</dt>
                <dd className="font-mono text-xl tabular-nums text-ink">{gap == null ? "—" : formatGap(gap)}</dd>
              </div>
            </dl>
          </section>

          <section className="rounded-xl border border-line bg-surface p-5" aria-label="Run controls">
            {snap.mode === "coin" ? (
              <div className="mb-5">
                <div className="flex items-baseline justify-between gap-3">
                  <p className="text-sm font-medium text-ink">Chance of heads</p>
                  <span className="font-mono text-sm tabular-nums text-muted">{Math.round(snap.pHeads * 100)}%</span>
                </div>
                <Slider
                  label="Chance of heads"
                  min={MIN_HEADS}
                  max={MAX_HEADS}
                  step={0.05}
                  value={snap.pHeads}
                  onChange={onHeads}
                />
                <p className="text-sm text-pretty text-muted">
                  The coin looks the same either way. Moving this starts a fresh set of flips.
                </p>
              </div>
            ) : null}

            <p className="text-sm font-medium text-ink" id="trial-label">
              How many to add
            </p>
            <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-labelledby="trial-label">
              {TRIAL_PRESETS.map((count) => {
                const on = snap.trials === count && trialDraft === String(count);
                return (
                  <button
                    key={count}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    className={cn(
                      "press min-h-11 rounded-sm border px-3 font-mono text-sm tabular-nums",
                      on ? "border-accent bg-accent text-accent-fg" : "border-line bg-elevated text-ink",
                    )}
                    onClick={() => chooseTrials(count)}
                  >
                    {count.toLocaleString()}
                  </button>
                );
              })}
            </div>
            <label className="mt-3 block text-sm text-muted" htmlFor="trial-count">
              Or type a count, up to {MAX_TRIALS.toLocaleString()}
            </label>
            <input
              id="trial-count"
              inputMode="numeric"
              className="mt-1 h-11 w-full rounded-sm border border-line-strong bg-elevated px-3 font-mono text-sm tabular-nums text-ink outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              value={trialDraft}
              onChange={(event) => {
                const cleaned = event.target.value.replace(/[^\d]/g, "").slice(0, 6);
                setTrialDraft(cleaned);
              }}
              onBlur={() => {
                if (!draftOk) {
                  setTrialDraft(String(snap.trials));
                  return;
                }
                chooseTrials(parsedTrials);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  run();
                }
              }}
            />

            <div className="mt-5 flex items-baseline justify-between gap-3">
              <p className="text-sm font-medium text-ink">Roll speed</p>
              <p className="text-sm text-muted">{speedLabel(snap.speed)}</p>
            </div>
            <Slider label="Roll speed" min={0} max={100} step={1} value={snap.speed} onChange={onSpeed} />
            <p className="text-sm text-pretty text-muted">{speedHint(snap.speed)}</p>

            <div className="mt-5 grid grid-cols-2 gap-2">
              <Button onClick={run} disabled={!draftOk || (snap.settling && !snap.running)} className="col-span-2">
                {snap.running ? <Pause className="size-4" aria-hidden="true" /> : <Play className="size-4" aria-hidden="true" />}
                {primary}
              </Button>
              <Button variant="secondary" onClick={step} disabled={snap.running || snap.settling}>
                Step
              </Button>
              <Button variant="secondary" onClick={reset} disabled={snap.n === 0 && !snap.running && !snap.settling}>
                <RotateCcw className="size-4" aria-hidden="true" />
                Reset
              </Button>
            </div>
          </section>

          <section className="rounded-xl border border-line bg-surface p-5">
            <h2 className="font-display text-2xl text-ink">How to read it</h2>
            <p className="mt-2 text-pretty text-muted">{modeLesson(snap.mode, snap.pHeads)}</p>
            <p className="mt-2 text-pretty text-muted">{focusLesson(snap.mode, focus)}</p>
            <p className="mt-2 text-pretty text-muted">{wobbleCopy(snap.n, share, focus.theory, focus.label)}</p>
            {averageGap != null ? (
              <p className="mt-3 font-mono text-sm tabular-nums text-ink">
                Average gap across outcomes: {averageGap.toFixed(1)} points
              </p>
            ) : null}
          </section>
        </div>

        <div className="flex min-w-0 flex-col gap-4 lg:col-span-2">
          <ChanceCharts
            rows={rows}
            focus={focusIndex}
            onFocus={onFocus}
            trace={snap.trace}
            theory={focus.theory}
            outcomeLabel={focus.label}
          />
          <section className="min-w-0 rounded-xl border border-line bg-surface p-5" aria-labelledby="table-title">
            <h2 id="table-title" className="font-display text-2xl text-ink">
              Counts
            </h2>
            <p className="mt-1 text-sm text-pretty text-muted">
              Expected count is the chance times the trials so far. Gap is your percent minus that chance, in points.
            </p>
            <div className="mt-4 max-w-full overflow-x-auto">
              <table className="w-full min-w-max border-collapse text-left text-sm">
                <caption className="sr-only">Outcome counts compared with the expected chance</caption>
                <thead>
                  <tr className="text-muted">
                        <th scope="col" className="sticky left-0 bg-surface py-2 pr-3 font-medium whitespace-nowrap">
                      Outcome
                    </th>
                    {snap.mode !== "coin" ? (
                      <th scope="col" className="px-3 py-2 font-medium">
                        Ways
                      </th>
                    ) : null}
                    <th scope="col" className="px-3 py-2 text-right font-medium">
                      Count
                    </th>
                    <th scope="col" className="px-3 py-2 text-right font-medium">
                      Expected
                    </th>
                    <th scope="col" className="px-3 py-2 text-right font-medium">
                      Yours
                    </th>
                    <th scope="col" className="px-3 py-2 text-right font-medium">
                      Chance
                    </th>
                    <th scope="col" className="py-2 pl-3 text-right font-medium">
                      Gap
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {outcomes.map((outcome, index) => {
                    const count = snap.counts[index] ?? 0;
                    const yours = snap.n === 0 ? null : count / snap.n;
                    const rowGap = yours == null ? null : (yours - outcome.theory) * 100;
                    const selected = index === focusIndex;
                    return (
                      <tr
                        key={outcome.id}
                        aria-selected={selected}
                        tabIndex={0}
                        className={cn(
                          "cursor-pointer border-t border-line outline-none focus-visible:bg-elevated",
                          selected ? "bg-elevated" : "hover:bg-elevated",
                        )}
                        onClick={() => onFocus(index)}
                        onKeyDown={(event) => {
                          if (event.key === "Enter" || event.key === " ") {
                            event.preventDefault();
                            onFocus(index);
                          }
                        }}
                      >
                        <th scope="row" className={cn("sticky left-0 py-2.5 pr-3 font-medium whitespace-nowrap", selected ? "bg-elevated text-ink" : "bg-surface text-ink")}>
                          {outcome.label}
                        </th>
                        {snap.mode !== "coin" ? (
                          <td className="px-3 py-2.5 font-mono tabular-nums text-muted">
                            {outcome.ways}/{outcome.waysTotal}
                          </td>
                        ) : null}
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums">{count.toLocaleString()}</td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums text-muted">
                          {snap.n === 0 ? "—" : (outcome.theory * snap.n).toFixed(1)}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                          {yours == null ? "—" : prettyPct(yours)}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums text-muted">{prettyPct(outcome.theory)}</td>
                        <td className="py-2.5 pl-3 text-right font-mono tabular-nums">{rowGap == null ? "—" : formatGap(rowGap)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}
