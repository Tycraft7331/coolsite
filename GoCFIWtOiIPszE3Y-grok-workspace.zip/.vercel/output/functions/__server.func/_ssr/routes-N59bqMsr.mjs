import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as Pause, n as RotateCcw, r as Play } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { a as Line, c as Bar, d as Tooltip, i as XAxis, l as Cell, n as LineChart, o as CartesianGrid, r as YAxis, s as ReferenceLine, t as ComposedChart, u as ResponsiveContainer } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-N59bqMsr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("press inline-flex items-center justify-center gap-2 rounded-sm px-4 text-sm font-medium min-h-11 select-none disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", {
	variants: { variant: {
		primary: "bg-accent text-accent-fg hover:bg-accent/90",
		secondary: "border border-line-strong bg-surface text-ink hover:bg-elevated",
		quiet: "bg-transparent text-ink hover:bg-elevated"
	} },
	defaultVariants: { variant: "primary" }
});
function Button({ className, variant, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({ variant }), className),
		...props
	});
}
function Slider({ value, onChange, min, max, step, label, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex h-11 w-full touch-none items-center px-3 select-none", className),
		value: [value],
		min,
		max,
		step,
		"aria-label": label,
		onValueChange: ([next]) => {
			if (next != null) onChange(next);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 grow rounded-full bg-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "relative block size-11 rounded-full bg-transparent outline-none before:absolute before:inset-3.5 before:rounded-full before:border before:border-line-strong before:bg-surface before:shadow-panel focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent" })]
	});
}
var PIPS = {
	1: [
		false,
		false,
		false,
		false,
		true,
		false,
		false,
		false,
		false
	],
	2: [
		true,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		true
	],
	3: [
		true,
		false,
		false,
		false,
		true,
		false,
		false,
		false,
		true
	],
	4: [
		true,
		false,
		true,
		false,
		false,
		false,
		true,
		false,
		true
	],
	5: [
		true,
		false,
		true,
		false,
		true,
		false,
		true,
		false,
		true
	],
	6: [
		true,
		false,
		true,
		true,
		false,
		true,
		true,
		false,
		true
	]
};
function Pips({ value, small }) {
	const cells = value == null ? Array.from({ length: 9 }, () => false) : PIPS[value];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: small ? "pip-grid pip-grid-sm" : "pip-grid",
		"aria-hidden": "true",
		children: cells.map((on, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: on ? "pip pip-on" : "pip" }, i))
	});
}
function DieFace({ value, small, spinId, spinMs }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (spinMs <= 0) {
			el.classList.remove("die-land");
			return;
		}
		el.classList.remove("die-land");
		el.offsetWidth;
		el.style.animationDuration = `${spinMs}ms`;
		el.classList.add("die-land");
	}, [spinId, spinMs]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: small ? "die-tile die-tile-sm" : "die-tile",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pips, {
			value,
			small
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: value == null ? "No roll yet" : `Face ${value}`
		})]
	});
}
function Coin({ side, spinId, spinMs }) {
	const rot = (0, import_react.useRef)(0);
	const body = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = body.current;
		if (!el || side == null) return;
		const base = side === "H" ? 0 : 180;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || spinMs <= 0) {
			rot.current = base;
			el.style.transitionDuration = "0ms";
			el.style.transform = `rotateY(${base}deg)`;
			return;
		}
		let next = base + 360 * Math.ceil((rot.current - base + 1) / 360);
		if (next <= rot.current) next += 360;
		if (next < rot.current + 360) next += 360;
		rot.current = next;
		el.style.transitionDuration = `${spinMs}ms`;
		el.style.transform = `rotateY(${next}deg)`;
	}, [
		side,
		spinId,
		spinMs
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "coin-scene",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: body,
			className: "coin-body",
			style: { transform: "rotateY(0deg)" },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "coin-face",
				children: "Heads"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "coin-face coin-tails",
				children: "Tails"
			})]
		})
	});
}
function ChanceStage({ mode, faces, status, spinId, spinMs }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-48 flex-col items-center justify-center gap-4 py-2",
		children: [
			mode === "coin" && faces.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "coin-idle",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Coin" })
			}) : null,
			mode === "coin" && faces.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coin, {
				side: faces[0] === 0 ? "H" : "T",
				spinId,
				spinMs
			}) : null,
			mode === "die" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DieFace, {
				value: faces[0] ?? null,
				spinId,
				spinMs
			}) : null,
			mode === "dice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DieFace, {
						value: faces[0] ?? null,
						small: true,
						spinId,
						spinMs
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl text-muted",
						"aria-hidden": "true",
						children: "+"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DieFace, {
						value: faces[1] ?? null,
						small: true,
						spinId: spinId + 1,
						spinMs
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-4xl tabular-nums text-ink",
						children: faces.length === 2 ? faces[0] + faces[1] : "–"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: status
			})
		]
	});
}
var TRIAL_PRESETS = [
	20,
	100,
	500,
	2e3,
	1e4
];
var MAX_TRIALS = 5e4;
var MIN_HEADS = .05;
var MAX_HEADS = .95;
var STARTERS = [
	{
		id: "fair",
		label: "Fair coin",
		mode: "coin",
		pHeads: .5,
		trials: 100,
		speed: 8
	},
	{
		id: "heavy",
		label: "Heavy heads",
		mode: "coin",
		pHeads: .7,
		trials: 200,
		speed: 28
	},
	{
		id: "die",
		label: "Single die",
		mode: "die",
		pHeads: .5,
		trials: 120,
		speed: 14
	},
	{
		id: "seven",
		label: "Why 7 is common",
		mode: "dice",
		pHeads: .5,
		trials: 360,
		speed: 40
	}
];
var DICE_WAYS = [
	1,
	2,
	3,
	4,
	5,
	6,
	5,
	4,
	3,
	2,
	1
];
function outcomesFor(mode, pHeads) {
	if (mode === "coin") {
		const p = clampHeads(pHeads);
		return [{
			id: "H",
			label: "Heads",
			short: "H",
			theory: p
		}, {
			id: "T",
			label: "Tails",
			short: "T",
			theory: 1 - p
		}];
	}
	if (mode === "die") return [
		1,
		2,
		3,
		4,
		5,
		6
	].map((face) => ({
		id: String(face),
		label: `Face ${face}`,
		short: String(face),
		theory: 1 / 6,
		ways: 1,
		waysTotal: 6
	}));
	return DICE_WAYS.map((ways, i) => {
		const sum = i + 2;
		return {
			id: String(sum),
			label: `Sum ${sum}`,
			short: String(sum),
			theory: ways / 36,
			ways,
			waysTotal: 36
		};
	});
}
function defaultFocus(mode) {
	if (mode === "coin") return 0;
	if (mode === "die") return 0;
	return 5;
}
function clampHeads(p) {
	const stepped = Math.round(p * 20) / 20;
	return Math.min(MAX_HEADS, Math.max(MIN_HEADS, stepped));
}
function clampTrials(n) {
	if (!Number.isFinite(n)) return 100;
	return Math.min(MAX_TRIALS, Math.max(1, Math.floor(n)));
}
function rollOutcome(mode, pHeads) {
	if (mode === "coin") {
		const index = Math.random() < clampHeads(pHeads) ? 0 : 1;
		return {
			index,
			faces: [index]
		};
	}
	const a = 1 + Math.floor(Math.random() * 6);
	if (mode === "die") return {
		index: a - 1,
		faces: [a]
	};
	const b = 1 + Math.floor(Math.random() * 6);
	return {
		index: a + b - 2,
		faces: [a, b]
	};
}
function pairsForSum(sum) {
	const pairs = [];
	for (let a = 1; a <= 6; a += 1) {
		const b = sum - a;
		if (b >= 1 && b <= 6) pairs.push(`${a}+${b}`);
	}
	return pairs.join(", ");
}
function spinDuration(speed) {
	if (speed > 22) return 0;
	const t = Math.min(1, Math.max(0, speed / 22));
	return Math.round(560 - t * 420);
}
function batchSize(speed, remaining) {
	if (remaining <= 0) return 0;
	if (speed <= 22) return 1;
	const t = Math.min(1, (speed - 22) / 78);
	const n = Math.max(1, Math.round(10 ** (t * 3.15)));
	return Math.min(remaining, n, 800);
}
function speedLabel(speed) {
	if (speed <= 8) return "One at a time";
	if (speed <= 22) return "Watch each";
	if (speed <= 48) return "Steady";
	if (speed <= 76) return "Fast";
	return "Burst";
}
function speedHint(speed) {
	if (speed <= 22) return "Each roll lands before the next one starts.";
	if (speed <= 76) return "Rolls arrive in slices, and the chart updates with them.";
	return "Large slices. The bars still move while the run is going.";
}
function formatPct(probability, digits = 1) {
	return `${(probability * 100).toFixed(digits)}%`;
}
function prettyPct(probability) {
	const hundred = probability * 100;
	const nearest = Math.round(hundred);
	if (Math.abs(hundred - nearest) < .05) return `${nearest}%`;
	return `${hundred.toFixed(1)}%`;
}
function formatGap(points) {
	if (points > .05) return `+${points.toFixed(1)}`;
	if (points < -.05) return `−${Math.abs(points).toFixed(1)}`;
	return "0.0";
}
function standardError(p, n) {
	if (n <= 0) return 0;
	return Math.sqrt(p * (1 - p) / n);
}
function meanAbsGap(counts, theories, n) {
	if (n <= 0 || theories.length === 0) return null;
	let sum = 0;
	for (let i = 0; i < theories.length; i += 1) sum += Math.abs(counts[i] / n - theories[i]);
	return sum / theories.length * 100;
}
function modeLesson(mode, pHeads) {
	if (mode === "coin") {
		const p = Math.round(clampHeads(pHeads) * 100);
		if (p === 50) return "A fair coin has no memory. A streak of heads does not make tails due.";
		return `Heads is set to ${p}%, so tails is ${100 - p}%. The coin is not trying to catch up.`;
	}
	if (mode === "die") return "Each face has the same chance, 1 in 6. Early on, one face can lead by luck alone.";
	return "Sums are not equally likely. More face pairs add to 7 than to 2.";
}
function focusLesson(mode, outcome) {
	if (mode === "dice" && outcome.ways != null) {
		const ways = outcome.ways === 1 ? "1 way" : `${outcome.ways} ways`;
		return `${outcome.label} can happen ${ways} out of 36: ${pairsForSum(Number(outcome.id))}.`;
	}
	if (mode === "die") return `${outcome.label} is no more likely than any other face. The previous roll does not change this one.`;
	return `${outcome.label} does not get more likely just because it has been rare so far.`;
}
function wobbleCopy(n, share, theory, label) {
	if (n <= 0) return "Run some trials. The gap between what happened and the expected chance is the thing to watch.";
	if (n < 8) return "With so few trials, a large gap is normal. Keep going before you judge.";
	const se = standardError(theory, n);
	const band = se * 100;
	const gap = Math.abs(share - theory);
	const usual = `${label} usually lands within about ±${band.toFixed(1)} points of ${prettyPct(theory)} at this count.`;
	if (gap <= se) return `${usual} This run is inside that usual wobble.`;
	if (gap <= 2 * se) return `${usual} This gap is a little wide, and still ordinary noise.`;
	return `${usual} This gap is wider than usual. It can still be luck — add more trials before you decide the chance is wrong.`;
}
function pushTrace(trace, n, counts) {
	const shares = counts.map((count) => n === 0 ? 0 : count / n);
	const next = trace.slice();
	const point = {
		n,
		shares
	};
	if (next.length > 0 && next[next.length - 1].n === n) next[next.length - 1] = point;
	else next.push(point);
	if (next.length <= 300) return next;
	const kept = [next[0]];
	for (let i = 1; i < next.length - 1; i += 2) kept.push(next[i]);
	kept.push(next[next.length - 1]);
	return kept;
}
function HistTip({ active, payload }) {
	if (!active || !payload?.length) return null;
	const row = payload[0].payload;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm border border-line bg-surface px-3 py-2 text-sm shadow-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium text-ink",
				children: row.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tabular-nums text-muted",
				children: [
					"Happened ",
					row.count.toLocaleString(),
					" · ",
					row.observed.toFixed(1),
					"%"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tabular-nums text-muted",
				children: [
					"Expected about ",
					row.expected.toFixed(1),
					" · ",
					row.theory.toFixed(1),
					"%"
				]
			})
		]
	});
}
function ShareTip({ active, payload }) {
	if (!active || !payload?.length) return null;
	const row = payload[0].payload;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm border border-line bg-surface px-3 py-2 text-sm shadow-panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "tabular-nums text-ink",
			children: [
				"After ",
				row.n.toLocaleString(),
				" trials"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "tabular-nums text-muted",
			children: [formatPct(row.share), " so far"]
		})]
	});
}
function ChanceCharts({ rows, focus, onFocus, trace, theory, outcomeLabel }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	const peak = Math.max(1, ...rows.map((row) => Math.max(row.observed, row.theory)));
	const yMax = Math.min(100, peak * 1.28);
	const line = trace.map((point) => ({
		n: point.n,
		share: point.shares[focus] ?? 0
	}));
	const lastN = line.length > 0 ? line[line.length - 1].n : 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0 rounded-xl border border-line bg-surface p-5",
			"aria-labelledby": "hist-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "hist-title",
						className: "font-display text-2xl text-ink",
						children: "What happened"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm text-pretty text-muted",
						children: "Bars are the trials you have rolled. The dashed line is the chance you should expect if you kept going."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-3 w-3 rounded-sm bg-accent",
								"aria-hidden": "true"
							}), "Happened"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-px w-5 border-t-2 border-dashed border-ink",
								"aria-hidden": "true"
							}), "Expected"]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-64 min-w-0 overflow-hidden sm:h-72",
					role: "img",
					"aria-label": "Histogram comparing what happened with the expected chance. Exact numbers are in the table.",
					children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						minWidth: 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComposedChart, {
							data: rows,
							margin: {
								top: 8,
								right: 4,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									vertical: false,
									stroke: "var(--color-line)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "short",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									tickLine: false,
									axisLine: false,
									interval: 0
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									domain: [0, yMax],
									tickFormatter: (value) => `${Math.round(value)}%`,
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									tickLine: false,
									axisLine: false,
									width: 44
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistTip, {}),
									cursor: { fill: "var(--color-elevated)" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "observed",
									maxBarSize: 48,
									radius: [
										4,
										4,
										0,
										0
									],
									isAnimationActive: false,
									cursor: "pointer",
									onClick: (_data, index) => {
										if (typeof index === "number") onFocus(index);
									},
									children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
										fill: "var(--color-accent)",
										fillOpacity: index === focus ? 1 : .45
									}, row.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "linear",
									dataKey: "theory",
									stroke: "var(--color-ink)",
									strokeDasharray: "4 3",
									strokeWidth: 1.5,
									dot: {
										r: 2.5,
										stroke: "var(--color-ink)",
										strokeWidth: 1.5,
										fill: "var(--color-surface)"
									},
									activeDot: { r: 4 },
									isAnimationActive: false
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full rounded-sm bg-elevated" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Select a bar or a table row to follow that outcome below."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0 rounded-xl border border-line bg-surface p-5",
			"aria-labelledby": "share-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					id: "share-title",
					className: "font-display text-2xl text-ink",
					children: [
						"Share of ",
						outcomeLabel,
						" so far"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm text-pretty text-muted",
					children: "Early on this swings hard. More trials pull it toward the dashed line. That is the law of large numbers."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 h-48 min-w-0 overflow-hidden",
					role: "img",
					"aria-label": `Running share of ${outcomeLabel} compared with the expected chance.`,
					children: ready && line.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						minWidth: 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
							data: line,
							margin: {
								top: 8,
								right: 8,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									vertical: false,
									stroke: "var(--color-line)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "n",
									type: "number",
									domain: [1, Math.max(lastN, 2)],
									tickFormatter: (value) => value.toLocaleString(),
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									tickLine: false,
									axisLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									domain: [0, 1],
									tickFormatter: (value) => `${Math.round(value * 100)}%`,
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									tickLine: false,
									axisLine: false,
									width: 44
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareTip, {}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceLine, {
									y: theory,
									stroke: "var(--color-ink)",
									strokeDasharray: "4 3",
									strokeWidth: 1.5
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "share",
									stroke: "var(--color-accent)",
									strokeWidth: 2,
									dot: false,
									isAnimationActive: false
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full items-center justify-center rounded-sm bg-elevated px-4 text-center text-sm text-muted",
						children: "The line starts with the first trial."
					})
				})
			]
		})]
	});
}
function outcomeRows(outcomes, counts, n) {
	return outcomes.map((outcome, index) => {
		const count = counts[index] ?? 0;
		return {
			id: outcome.id,
			label: outcome.label,
			short: outcome.short,
			observed: n === 0 ? 0 : count / n * 100,
			theory: outcome.theory * 100,
			count,
			expected: outcome.theory * n
		};
	});
}
function freshCounts(mode, pHeads) {
	return Array.from({ length: outcomesFor(mode, pHeads).length }, () => 0);
}
function createEngine() {
	return {
		mode: "coin",
		pHeads: .5,
		speed: 12,
		trials: 100,
		focus: 0,
		running: false,
		remaining: 0,
		counts: freshCounts("coin", .5),
		n: 0,
		faces: [],
		trace: [],
		spinId: 0,
		spinMs: 0,
		settling: false,
		token: 0,
		timer: 0,
		raf: 0,
		announceOnStop: false
	};
}
function shot(engine) {
	return {
		mode: engine.mode,
		pHeads: engine.pHeads,
		speed: engine.speed,
		trials: engine.trials,
		focus: engine.focus,
		running: engine.running,
		remaining: engine.remaining,
		counts: engine.counts.slice(),
		n: engine.n,
		faces: engine.faces.slice(),
		trace: engine.trace.map((point) => ({
			n: point.n,
			shares: point.shares.slice()
		})),
		spinId: engine.spinId,
		spinMs: engine.spinMs,
		settling: engine.settling
	};
}
function prefersReduced() {
	return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function stopTimers(engine) {
	window.clearTimeout(engine.timer);
	window.cancelAnimationFrame(engine.raf);
}
var MODES = [
	{
		id: "coin",
		label: "Coin"
	},
	{
		id: "die",
		label: "One die"
	},
	{
		id: "dice",
		label: "Two dice"
	}
];
function Simulator() {
	const engineRef = (0, import_react.useRef)(null);
	if (engineRef.current == null) engineRef.current = createEngine();
	const engine = engineRef.current;
	const [snap, setSnap] = (0, import_react.useState)(() => shot(engine));
	const [announcement, setAnnouncement] = (0, import_react.useState)("");
	const [trialDraft, setTrialDraft] = (0, import_react.useState)("100");
	const api = (0, import_react.useRef)({
		pump: () => {},
		landOne: (_continueQueue, _visual, _wait) => {},
		finishNote: () => {}
	});
	api.current.finishNote = () => {
		const current = engineRef.current;
		if (!current) return;
		const outcomes = outcomesFor(current.mode, current.pHeads);
		const outcome = outcomes[current.focus] ?? outcomes[0];
		const share = current.n === 0 ? 0 : current.counts[current.focus] / current.n;
		setAnnouncement(`Run finished. ${current.n.toLocaleString()} trials. ${outcome.label} ${prettyPct(share)}. Expected ${prettyPct(outcome.theory)}.`);
	};
	api.current.landOne = (continueQueue, visual, wait) => {
		const current = engineRef.current;
		if (!current) return;
		const token = current.token;
		const rolled = rollOutcome(current.mode, current.pHeads);
		current.settling = true;
		current.faces = rolled.faces;
		current.spinId += 1;
		current.spinMs = visual;
		setSnap(shot(current));
		current.timer = window.setTimeout(() => {
			const live = engineRef.current;
			if (!live || live.token !== token) return;
			live.counts[rolled.index] += 1;
			live.n += 1;
			if (live.remaining > 0) live.remaining -= 1;
			live.trace = pushTrace(live.trace, live.n, live.counts);
			live.settling = false;
			live.spinMs = 0;
			const queueDone = live.remaining <= 0;
			if (!continueQueue || !live.running || queueDone) {
				const shouldAnnounce = live.announceOnStop && queueDone;
				live.running = false;
				if (shouldAnnounce) {
					live.announceOnStop = false;
					api.current.finishNote();
				}
				setSnap(shot(live));
				return;
			}
			setSnap(shot(live));
			api.current.pump();
		}, wait);
	};
	api.current.pump = () => {
		const current = engineRef.current;
		if (!current || !current.running) return;
		if (current.remaining <= 0) {
			current.running = false;
			if (current.announceOnStop) {
				current.announceOnStop = false;
				api.current.finishNote();
			}
			setSnap(shot(current));
			return;
		}
		const visual = prefersReduced() ? 0 : spinDuration(current.speed);
		const wait = visual > 0 ? visual : current.speed <= 22 ? 80 : 0;
		if (wait > 0) {
			api.current.landOne(true, visual, wait);
			return;
		}
		const count = batchSize(current.speed, current.remaining);
		let faces = current.faces;
		for (let i = 0; i < count; i += 1) {
			const rolled = rollOutcome(current.mode, current.pHeads);
			current.counts[rolled.index] += 1;
			faces = rolled.faces;
		}
		current.n += count;
		current.remaining -= count;
		current.faces = faces;
		current.spinMs = 0;
		current.settling = false;
		current.trace = pushTrace(current.trace, current.n, current.counts);
		if (current.remaining <= 0) {
			current.running = false;
			if (current.announceOnStop) {
				current.announceOnStop = false;
				api.current.finishNote();
			}
		}
		setSnap(shot(current));
		if (current.running) current.raf = window.requestAnimationFrame(() => api.current.pump());
	};
	(0, import_react.useEffect)(() => {
		const current = engineRef.current;
		return () => {
			if (!current) return;
			current.token += 1;
			current.running = false;
			stopTimers(current);
		};
	}, []);
	function publish() {
		const current = engineRef.current;
		if (current) setSnap(shot(current));
	}
	function wipeSample(next) {
		const current = engineRef.current;
		if (!current) return;
		current.token += 1;
		current.running = false;
		current.settling = false;
		current.announceOnStop = false;
		stopTimers(current);
		if (next?.mode) current.mode = next.mode;
		if (next?.pHeads != null) current.pHeads = clampHeads(next.pHeads);
		current.focus = defaultFocus(current.mode);
		current.counts = freshCounts(current.mode, current.pHeads);
		current.n = 0;
		current.remaining = 0;
		current.faces = [];
		current.trace = [];
		current.spinMs = 0;
		setAnnouncement("");
		publish();
	}
	function onMode(mode) {
		if (mode === engineRef.current?.mode) return;
		wipeSample({ mode });
	}
	function onHeads(value) {
		const next = clampHeads(value);
		const current = engineRef.current;
		if (!current || next === current.pHeads) return;
		wipeSample({ pHeads: next });
	}
	function onSpeed(value) {
		const current = engineRef.current;
		if (!current) return;
		current.speed = value;
		publish();
	}
	function onFocus(index) {
		const current = engineRef.current;
		if (!current) return;
		current.focus = index;
		publish();
	}
	function chooseTrials(count) {
		const current = engineRef.current;
		if (!current) return;
		current.trials = clampTrials(count);
		setTrialDraft(String(current.trials));
		publish();
	}
	function applyStarter(id) {
		const starter = STARTERS.find((item) => item.id === id);
		const current = engineRef.current;
		if (!starter || !current) return;
		current.speed = starter.speed;
		current.trials = starter.trials;
		setTrialDraft(String(starter.trials));
		wipeSample({
			mode: starter.mode,
			pHeads: starter.pHeads
		});
	}
	function reset() {
		wipeSample();
	}
	function run() {
		const current = engineRef.current;
		if (!current) return;
		if (current.running) {
			current.running = false;
			current.announceOnStop = false;
			window.cancelAnimationFrame(current.raf);
			publish();
			return;
		}
		if (current.settling) return;
		if (current.remaining <= 0) {
			const count = clampTrials(Number(trialDraft));
			current.trials = count;
			current.remaining = count;
			setTrialDraft(String(count));
		}
		current.running = true;
		current.announceOnStop = true;
		publish();
		api.current.pump();
	}
	function step() {
		const current = engineRef.current;
		if (!current || current.running || current.settling) return;
		const reduce = prefersReduced();
		api.current.landOne(false, reduce ? 0 : 320, reduce ? 0 : 320);
	}
	const outcomes = (0, import_react.useMemo)(() => outcomesFor(snap.mode, snap.pHeads), [snap.mode, snap.pHeads]);
	const focusIndex = Math.min(snap.focus, outcomes.length - 1);
	const focus = outcomes[focusIndex];
	const rows = (0, import_react.useMemo)(() => outcomeRows(outcomes, snap.counts, snap.n), [
		outcomes,
		snap.counts,
		snap.n
	]);
	const share = snap.n === 0 ? 0 : (snap.counts[focusIndex] ?? 0) / snap.n;
	const gap = snap.n === 0 ? null : (share - focus.theory) * 100;
	const averageGap = meanAbsGap(snap.counts, outcomes.map((outcome) => outcome.theory), snap.n);
	let status = "Ready";
	if (snap.settling) status = "In the air";
	else if (snap.mode === "coin" && snap.faces.length > 0) status = snap.faces[0] === 0 ? "Heads" : "Tails";
	else if (snap.mode === "die" && snap.faces.length > 0) status = `Face ${snap.faces[0]}`;
	else if (snap.mode === "dice" && snap.faces.length === 2) status = `Sum ${snap.faces[0] + snap.faces[1]}`;
	const parsedTrials = clampTrials(Number(trialDraft));
	const draftOk = Number.isFinite(Number(trialDraft)) && Number(trialDraft) >= 1;
	let primary = `Run ${parsedTrials.toLocaleString()}`;
	if (snap.running) primary = "Pause";
	else if (snap.settling) primary = "Landing";
	else if (snap.remaining > 0) primary = `Resume ${snap.remaining.toLocaleString()}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl overflow-x-clip px-4 pt-8 pb-24 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: announcement
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-muted",
						children: "Probability bench"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-display text-ink",
						children: "The Long Run"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-pretty text-muted",
						children: "Flip a coin or roll dice, again and again. Watch the bars chase the chance you should expect."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				role: "group",
				"aria-label": "Starting setups",
				children: STARTERS.map((starter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					className: "border border-line bg-surface",
					onClick: () => applyStarter(starter.id),
					children: starter.label
				}, starter.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid min-w-0 gap-4 lg:grid-cols-3 lg:items-start lg:gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-line bg-surface p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-3 gap-1 rounded-md bg-elevated p-1",
									role: "radiogroup",
									"aria-label": "Experiment",
									children: MODES.map((mode) => {
										const on = snap.mode === mode.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											role: "radio",
											"aria-checked": on,
											className: cn("press min-h-11 rounded-sm px-2 text-sm font-medium", on ? "bg-accent text-accent-fg" : "text-muted hover:text-ink"),
											onClick: () => onMode(mode.id),
											children: mode.label
										}, mode.id);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChanceStage, {
									mode: snap.mode,
									faces: snap.faces,
									status,
									spinId: snap.spinId,
									spinMs: snap.spinMs
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "grid grid-cols-2 gap-3 border-t border-line pt-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-sm text-muted",
											children: "Trials so far"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-mono text-xl tabular-nums text-ink",
											children: snap.n.toLocaleString()
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
											className: "text-sm text-muted",
											children: ["Following ", focus.short]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-mono text-xl tabular-nums text-ink",
											children: snap.n === 0 ? "—" : prettyPct(share)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-sm text-muted",
											children: "Expected"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-mono text-xl tabular-nums text-ink",
											children: prettyPct(focus.theory)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-sm text-muted",
											children: "Gap, points"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-mono text-xl tabular-nums text-ink",
											children: gap == null ? "—" : formatGap(gap)
										})] })
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-line bg-surface p-5",
							"aria-label": "Run controls",
							children: [
								snap.mode === "coin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-baseline justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-medium text-ink",
												children: "Chance of heads"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono text-sm tabular-nums text-muted",
												children: [Math.round(snap.pHeads * 100), "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
											label: "Chance of heads",
											min: MIN_HEADS,
											max: MAX_HEADS,
											step: .05,
											value: snap.pHeads,
											onChange: onHeads
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-pretty text-muted",
											children: "The coin looks the same either way. Moving this starts a fresh set of flips."
										})
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-ink",
									id: "trial-label",
									children: "How many to add"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									role: "radiogroup",
									"aria-labelledby": "trial-label",
									children: TRIAL_PRESETS.map((count) => {
										const on = snap.trials === count && trialDraft === String(count);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											role: "radio",
											"aria-checked": on,
											className: cn("press min-h-11 rounded-sm border px-3 font-mono text-sm tabular-nums", on ? "border-accent bg-accent text-accent-fg" : "border-line bg-elevated text-ink"),
											onClick: () => chooseTrials(count),
											children: count.toLocaleString()
										}, count);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-3 block text-sm text-muted",
									htmlFor: "trial-count",
									children: ["Or type a count, up to ", MAX_TRIALS.toLocaleString()]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "trial-count",
									inputMode: "numeric",
									className: "mt-1 h-11 w-full rounded-sm border border-line-strong bg-elevated px-3 font-mono text-sm tabular-nums text-ink outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
									value: trialDraft,
									onChange: (event) => {
										const cleaned = event.target.value.replace(/[^\d]/g, "").slice(0, 6);
										setTrialDraft(cleaned);
									},
									onBlur: () => {
										if (!draftOk) {
											setTrialDraft(String(snap.trials));
											return;
										}
										chooseTrials(parsedTrials);
									},
									onKeyDown: (event) => {
										if (event.key === "Enter") {
											event.preventDefault();
											run();
										}
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-ink",
										children: "Roll speed"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: speedLabel(snap.speed)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									label: "Roll speed",
									min: 0,
									max: 100,
									step: 1,
									value: snap.speed,
									onChange: onSpeed
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-pretty text-muted",
									children: speedHint(snap.speed)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 grid grid-cols-2 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: run,
											disabled: !draftOk || snap.settling && !snap.running,
											className: "col-span-2",
											children: [snap.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
												className: "size-4",
												"aria-hidden": "true"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
												className: "size-4",
												"aria-hidden": "true"
											}), primary]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "secondary",
											onClick: step,
											disabled: snap.running || snap.settling,
											children: "Step"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "secondary",
											onClick: reset,
											disabled: snap.n === 0 && !snap.running && !snap.settling,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
												className: "size-4",
												"aria-hidden": "true"
											}), "Reset"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-line bg-surface p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl text-ink",
									children: "How to read it"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-pretty text-muted",
									children: modeLesson(snap.mode, snap.pHeads)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-pretty text-muted",
									children: focusLesson(snap.mode, focus)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-pretty text-muted",
									children: wobbleCopy(snap.n, share, focus.theory, focus.label)
								}),
								averageGap != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 font-mono text-sm tabular-nums text-ink",
									children: [
										"Average gap across outcomes: ",
										averageGap.toFixed(1),
										" points"
									]
								}) : null
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col gap-4 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChanceCharts, {
						rows,
						focus: focusIndex,
						onFocus,
						trace: snap.trace,
						theory: focus.theory,
						outcomeLabel: focus.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "min-w-0 rounded-xl border border-line bg-surface p-5",
						"aria-labelledby": "table-title",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "table-title",
								className: "font-display text-2xl text-ink",
								children: "Counts"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-pretty text-muted",
								children: "Expected count is the chance times the trials so far. Gap is your percent minus that chance, in points."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 max-w-full overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full min-w-max border-collapse text-left text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
											className: "sr-only",
											children: "Outcome counts compared with the expected chance"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "text-muted",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													scope: "col",
													className: "sticky left-0 bg-surface py-2 pr-3 font-medium whitespace-nowrap",
													children: "Outcome"
												}),
												snap.mode !== "coin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													scope: "col",
													className: "px-3 py-2 font-medium",
													children: "Ways"
												}) : null,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													scope: "col",
													className: "px-3 py-2 text-right font-medium",
													children: "Count"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													scope: "col",
													className: "px-3 py-2 text-right font-medium",
													children: "Expected"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													scope: "col",
													className: "px-3 py-2 text-right font-medium",
													children: "Yours"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													scope: "col",
													className: "px-3 py-2 text-right font-medium",
													children: "Chance"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													scope: "col",
													className: "py-2 pl-3 text-right font-medium",
													children: "Gap"
												})
											]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: outcomes.map((outcome, index) => {
											const count = snap.counts[index] ?? 0;
											const yours = snap.n === 0 ? null : count / snap.n;
											const rowGap = yours == null ? null : (yours - outcome.theory) * 100;
											const selected = index === focusIndex;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												"aria-selected": selected,
												tabIndex: 0,
												className: cn("cursor-pointer border-t border-line outline-none focus-visible:bg-elevated", selected ? "bg-elevated" : "hover:bg-elevated"),
												onClick: () => onFocus(index),
												onKeyDown: (event) => {
													if (event.key === "Enter" || event.key === " ") {
														event.preventDefault();
														onFocus(index);
													}
												},
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														scope: "row",
														className: cn("sticky left-0 py-2.5 pr-3 font-medium whitespace-nowrap", selected ? "bg-elevated text-ink" : "bg-surface text-ink"),
														children: outcome.label
													}),
													snap.mode !== "coin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-3 py-2.5 font-mono tabular-nums text-muted",
														children: [
															outcome.ways,
															"/",
															outcome.waysTotal
														]
													}) : null,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2.5 text-right font-mono tabular-nums",
														children: count.toLocaleString()
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2.5 text-right font-mono tabular-nums text-muted",
														children: snap.n === 0 ? "—" : (outcome.theory * snap.n).toFixed(1)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2.5 text-right font-mono tabular-nums",
														children: yours == null ? "—" : prettyPct(yours)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2.5 text-right font-mono tabular-nums text-muted",
														children: prettyPct(outcome.theory)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-2.5 pl-3 text-right font-mono tabular-nums",
														children: rowGap == null ? "—" : formatGap(rowGap)
													})
												]
											}, outcome.id);
										}) })
									]
								})
							})
						]
					})]
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Simulator, {});
}
//#endregion
export { Home as component };
