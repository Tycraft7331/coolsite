//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B-xIlXwk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C-lnZ01u.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C-lnZ01u.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-qMl_FNJM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
